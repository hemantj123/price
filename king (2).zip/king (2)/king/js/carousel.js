 $('#myCarousel').carousel({
    //interval: 3000,
	interval: false,
}) 

$('#myCarousel2').carousel({
    interval: 4000
})

 
 $('.screenShtSec .carousel .carousel-item').each(function() {
    var minPerSlide = 4;
    var next = $(this).next();
    if (!next.length) {
        next = $(this).siblings(':first');
    }
    next.children(':first-child').clone().appendTo($(this));

    for (var i = 0; i < minPerSlide; i++) {
        next = next.next();
        if (!next.length) {
            next = $(this).siblings(':first');
        }

        next.children(':first-child').clone().appendTo($(this));
    }
}); 
